#include <stdio.h>

void main() {
	for(int i = 33; i < 127; i++) {
		printf("%c : %d\n", i, i);
	}
}